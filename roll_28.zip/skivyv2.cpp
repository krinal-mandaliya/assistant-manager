#include<iostream>
#include<conio.h>
#include<string.h>
#include <windows.h>
#include<dos.h>
#include<ctime>
#include<fstream>

using namespace std;
#define historyFile "hist11.txt"
class skivvy
{
	//private:



	public:
	    char command[100];
		void greeting()
		{

		      //	cin.getline(hi,100);
			gets(command);
		}
        void setCommand(char command[100])
        {
            strcpy(this->command,command);
        }
        char *getcommand()
        {
            return command;
        }
        };
class process:public skivvy
{
    public:


        void printgreet()
		{

		     STARTUPINFO startInfo = {0};
             PROCESS_INFORMATION processInfo={0};


			if(strcmp(command,"hey skivvy")==0)
			{
             cout<<":- Hello,How can i help?"<<endl<<endl;
                    /*string phrase = "Hello,How can i help?";
                    string command = "espeak \"" + phrase + "\"";
                    const char *charCommand = command.c_str();
                    system(charCommand);*/
                    PlaySound("Hello,How can i help.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"hello")==0 || strcmp(command,"hyy")==0 || strcmp(command,"hi")==0)
			{
				cout<<":- Hey,How can i help?"<<endl<<endl;
                    /*string phrase = "Hey,How can i help?";
                    string command = "espeak \"" + phrase + "\"";
                    const char *charCommand = command.c_str();
                    system(charCommand);*/
                    PlaySound("Hello,How can i help.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"hey")==0)
			{
				cout<<":- skivvy is on your service..."<<endl<<endl;
                   /* string phrase = "skivvy is on your service...";
                    string command = "espeak \"" + phrase + "\"";
                    const char *charCommand = command.c_str();
                    system(charCommand);*/
                    PlaySound("skivvy is on your service....wav",NULL,SND_SYNC);
			}

			if(strcmp(command,"what is your name")==0)
			{
				cout<<":- My name is skivvy your assistant"<<endl;
                PlaySound("My name is skivvy your assistant.wav",NULL,SND_SYNC);

			}
			else if(strcmp(command,"why are you here")==0)
			{
				cout<<":- To guide you"<<endl;
				cout<<":- To guide you"<<endl;
                PlaySound("To guide you.wav",NULL,SND_SYNC);
			}
			 else if(strcmp(command,"what is the time")==0)
                {

                    time_t now = time(0);
                    char *dt = ctime(&now);
                    cout<<"The date and time is "<<endl<<dt<<endl;
                }
			else if(strcmp(command,"open notepad")==0)
            {
                cout<<"opening notepad"<<endl;
                PlaySound("opening notepad.wav",NULL,SND_SYNC);
                    CreateProcess(TEXT("C:\\Windows\\notepad.exe"),NULL,NULL,NULL,FALSE,NULL,NULL,NULL,&startInfo,&processInfo);
            }
            else if(strcmp(command,"open calculator")==0)
            {
                cout<<"opening Calculator"<<endl;
                    PlaySound("opening Calculator.wav",NULL,SND_SYNC);
                    CreateProcess(TEXT("C:\\Windows\\WinSxS\\amd64_microsoft-windows-calc_31bf3856ad364e35_10.0.22000.51_none_8bfd8527368d91e4\\calc.exe"),NULL,NULL,NULL,FALSE,NULL,NULL,NULL,&startInfo,&processInfo);
            }
            else if(strcmp(command,"open google")==0)
            {
                cout<<"opening Google"<<endl;
                    PlaySound("opening Google.wav",NULL,SND_SYNC);
                    system("start https://www.google.com");
            }
            else if(strcmp(command,"open youtube")==0)
            {
                cout<<"opening Youtube"<<endl;
                    PlaySound("opening Youtube.wav",NULL,SND_SYNC);
                    system("start https://www.youtube.com");
            }
            else if(strcmp(command,"open facebook")==0)
            {
                cout<<"opening Facebook"<<endl;
                    PlaySound("opening Facebook.wav",NULL,SND_SYNC);
                    system("start https://facebook.com");
            }
            else if(strcmp(command,"open instagram")==0)
            {
                cout<<"opening instagram"<<endl;
                    PlaySound("opening instagram.wav",NULL,SND_SYNC);
                    system("start https://www.instagram.com");
            }
            else if(strcmp(command,"tell me joke")==0)
			{
             cout<<":- what to do you call a rose that wants to go to the moon------------:Gulab ja moon:"<<endl<<endl;
                    PlaySound("joke.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"another joke")==0 || strcmp(command,"once more")==0 || strcmp(command,"tell another joke")==0 || strcmp(command,"next joke")==0)
			{
             cout<<":- What is the longest word in english language 'smiles' because there is a mile between first and last letter"<<endl<<endl;
                    PlaySound("joke2.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"bored")==0)
			{
             cout<<":- wanna play game?...."<<endl<<endl;
                    PlaySound("wanna play game.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"yes")==0 ||strcmp(command,"play game")==0 || strcmp(command,"start game")==0)
             {
             cout<<":- Dinousur game is starting"<<endl<<endl;
                    PlaySound("Dinousur game is starting.wav",NULL,SND_SYNC);
                    system("start https://offline-dino-game.firebaseapp.com");
			}
            else if(strcmp(command,"give me compliment")==0)
			{
             cout<<":- You are valuable and shiny than gold"<<endl<<endl;
                    PlaySound("You are valuable and shiny than gold.wav",NULL,SND_SYNC);
			}
			 else if(strcmp(command,"todays weather")==0 || strcmp(command,"today's weather")==0)
			{
                    cout<<":- Opening weather"<<endl<<endl;
                    PlaySound("Opening weather.wav",NULL,SND_SYNC);
                    system("start https://www.bbc.com/weather/1279233");
			}
			else if(strcmp(command,"how are you")==0)
			{
             cout<<":- Fine,What about you?"<<endl<<endl;
                    PlaySound("Fine,What about you.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"play the song")==0)
            {
                cout<<"sure,Here you list of songs"<<endl;
                PlaySound("sure,Here you list of songs.wav",NULL,SND_SYNC);
			    int choice=0;
            do
            {
                cout<<":-           ------List of songs------"<<endl<<endl;
                cout<<"             1.Kesarya tera"<<endl;
                cout<<"             2.Pasoori"<<endl;
                cout<<"             3.Namo Namo"<<endl;
                cout<<"             4.Chala jaata hoon"<<endl;
                cout<<"             5.Humsafar"<<endl;
                cout<<"             6.Exit"<<endl;
                cout<<"             Your choice:";
                cin>>choice;

                switch(choice)
                    {
                    case 1:
                        PlaySound("kesariyaep.wav",NULL,SND_SYNC);
                        PlaySound("kesariya.wav",NULL,SND_SYNC);
                        break;
                    case 2:
                        PlaySound("pasooriep.wav",NULL,SND_SYNC);
                        PlaySound("pasoori.wav",NULL,SND_SYNC);
                        break;
                    case 3:
                        PlaySound("namo namoep.wav",NULL,SND_SYNC);
                        PlaySound("namo namo.wav",NULL,SND_SYNC);
                        break;
                    case 4:
                        PlaySound("chala jaata hoonep.wav",NULL,SND_SYNC);
                        PlaySound("chala jaata hoon.wav",NULL,SND_SYNC);
                        break;
                    case 5:
                        PlaySound("humsufarep.wav",NULL,SND_SYNC);
                        PlaySound("humsufar.wav",NULL,SND_SYNC);
                        break;
                    case 6:
                        break;
                    default:
                        cout<<"Invalid...";

                    }
                }while(choice!=6);
}
			else if(strcmp(command,"are you knowing siri")==0 || strcmp(command,"are you knowing siri?")==0 || strcmp(command,"are you knowing alexa")==0 || strcmp(command,"are you knowing alexa")==0)
			{
             cout<<":- Yes,She is good assistant as i am"<<endl<<endl;
                    PlaySound("Yes,She is good assistant as i am.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"who is better you or siri")==0 || strcmp(command,"who is better siri or you")==0 || strcmp(command,"who is better you or alexa")==0 || strcmp(command,"who is better alexa or you")==0)
			{
             cout<<":- Both are best on own points"<<endl<<endl;
                    PlaySound("Both are best on own points.wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"is siri is your enemy?")==0 || strcmp(command,"is siri is your enemy")==0 || strcmp(command,"is alexa is your enemy?")==0 || strcmp(command,"is alexa is your enemy")==0)
			{
             cout<<":- Not at all...,why we will be enemy. "<<endl<<endl;
                    PlaySound("Not at all...,why we will be enemy..wav",NULL,SND_SYNC);
			}
			else if(strcmp(command,"history")==0)
			{
             cout<<":- Here's your history"<<endl<<endl;
                    string phrase = "Here's your history";
                    string command = "espeak \"" + phrase + "\"";
                    const char *charCommand = command.c_str();
                    system(charCommand);
                   fstream fobj;
                   skivvy sk;
                    fobj.open(historyFile, ios::in);
                    fobj.read((char *)&sk, sizeof(sk));	// read the first record
                    while(!fobj.eof())
                    {
                        char o[500];
                        strcpy(o,sk.getcommand());
                        for(int i=0;o[i]!='\0';i++)
                        {
                            cout << (char)o[i];
                        }
                        fobj.read((char *)&sk, sizeof(sk));	// skip to next record

                    }
                    cout << "\n\t No history available....";
                    //system("pause");
                    fobj.close();
			}
            else if(strcmp(command,"exit")==0 || strcmp(command,"bye")==0)
               {
                   cout<<"Good bye"<<endl<<endl;
                    PlaySound("good bye.wav",NULL,SND_SYNC);
                   exit(0);
               }
            else
            {
                   cout<<"invalid";
            }

		}
};
class demo
{
public:
    demo()
    {
        time_t now = time(0);
    tm *time = localtime(&now);

    if (time-> tm_hour < 12){
        cout<< "Good Morning Sir"<<endl;
        PlaySound("Good Morning Sir.wav",NULL,SND_SYNC);
    }

    else if (time-> tm_hour >= 12 && time->tm_hour <= 16)
        {
        cout<< "Good Afternoon Sir"<<endl;
        PlaySound("Good Afternoon Sir.wav",NULL,SND_SYNC);
        }

    else if (time-> tm_hour > 16 && time->tm_hour < 24)
        {
        cout<< "Good Evening Sir"<<endl;
        PlaySound("Good Evening Sir.wav",NULL,SND_SYNC);
        }
    }
};
void writedata()
		{
		    fstream fobj;
            fobj.open(historyFile, ios::app);
            skivvy sk;
            //sk.greeting();
            fobj.write((char*)&sk, sizeof(sk));
            fobj.close();
		}

int main()
  {
      int i;
      system("cls");
      //greetings();
      demo obj;
      process sk[100];
      for(i=0;i<100;i++)
      {
        sk[i].greeting();
        writedata();
        sk[i].printgreet();
      }
      //skivvy sk2;
      //sk2.greeting();
      //sk2.printgreet();



      return 0;
  }
